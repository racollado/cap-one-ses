import React from "react";
import Select from "react-select";
import "./styles.css";
import axios from "axios";

// search bar that doubles for searching departure and destination
const CitySearchBar = (props) => {
  let searchText = "Where would you like to ";
  let key = undefined;
  if (props.step < 3) {
    searchText += "depart from? ";
    key = "csb";
  } else {
    searchText += "go? ";
    key = "dsb";
  }
  return (
    <form className="search" onSubmit={props.handleCitySubmit}>
      <label>{searchText}</label>
      <input
        key={key}
        value={props.value}
        onChange={props.handleCityChange}
        placeholder="Search by city or airport"
      />
      <button
        type="button"
        onClick={props.handleCitySubmit}
        className="search-button"
      >
        {" "}
        Search{" "}
      </button>
    </form>
  );
};

// table of city results after submitting departure or destination input
const ResultsTable = (props) => {
  if (props.cityData.length === 0) {
    return (
      <p className="errorCode">
        No results found for {props.value}, try again.{" "}
      </p>
    );
  } else {
    return (
      <>
        <h2>Results</h2>
        <form onSubmit={props.handleTableSubmit} className="table">
          {props.cityData.map((airport) => (
            <div
              className="result"
              key={`${airport.PlaceName}_${airport.PlaceId}`}
            >
              <label className="label">
                <input
                  type="radio"
                  value={airport.PlaceId}
                  checked={props.placeId === airport.PlaceId}
                  onChange={props.handleTableChange}
                />
                {"   "}
                {airport.PlaceName}, {airport.CountryName} ({airport.PlaceId})
              </label>
            </div>
          ))}
          <div className="submit-button-container">
            <button
              type="button"
              className="submit-button"
              onClick={props.handleTableSubmit}
            >
              Submit
            </button>
          </div>
        </form>
      </>
    );
  }
};

// date and currency selection elements
const DatesAndCurrency = (props) => {
  let currencyOptions = props.currencyData.map((currency) => {
    return {
      value: currency.Code,
      label: currency.Code + " (" + currency.Symbol + ")"
    };
  });
  const usdObj = currencyOptions.find((el) => {
    return el.value === "USD";
  });
  const idx = currencyOptions.indexOf(usdObj);
  currencyOptions.splice(idx, 1);
  currencyOptions.splice(0, 0, usdObj);
  const dropdown = (
    <Select
      className="currency-menu"
      options={currencyOptions}
      onChange={props.handleTableChange}
    />
  );
  return (
    <div>
      <form className="last" onSubmit={props.handleLastSubmit}>
        <label>When would you like to fly out?</label>
        <input
          key="dout"
          value={props.value1}
          onChange={props.handleLastInputChange1}
          placeholder="yyyy-mm, yyyy-mm-dd, or anytime"
        />
        <label>When would you like to fly back?</label>
        <input
          key="din"
          value={props.value2}
          onChange={props.handleLastInputChange2}
          placeholder="yyyy-mm, yyyy-mm-dd, or anytime"
        />
        <div className="currency">
          Select your preferred currency: {dropdown}{" "}
        </div>
        <div className="submit-button-container">
          <button
            type="button"
            className="submit-button"
            onClick={props.handleLastSubmit}
          >
            Submit
          </button>
        </div>
      </form>
    </div>
  );
};

// table that displays all quotes
const QuotesTable = ({ quoteData, currencyChoice }) => {
  if (quoteData.length === 0) {
    return <p className="error-code">Sorry, we couldn't find any flights. </p>;
  } else {
    return (
      <>
        <h2>Available Flights</h2>
        <div className="quote-table">
          {quoteData.map((flight, idx) => {
            let className = undefined;
            let header = null;
            if (idx < 3) {
              className = "hot-quote-result";
              header = (
                <>
                  🔥 Hot deal!🔥 <br />
                </>
              );
            } else {
              className = "quote-result";
            }
            return (
              <div className={className} key={`${flight.quoteId}`}>
                {header}#{flight.quoteId}) {currencyChoice}
                {flight.minPrice} {"  "}
                {flight.direct ? " - Direct flight" : " - Indirect flight"}
                <br /> {flight.departureCode} {"-->"} {flight.arrivalCode}{" "}
                {" on "} {flight.outboundDate} ({flight.outboundAirline})
                <br /> {flight.arrivalCode} {"-->"} {flight.departureCode}{" "}
                {" on "} {flight.inboundDate} ({flight.inboundAirline})
              </div>
            );
          })}
        </div>
      </>
    );
  }
};

// buttons that allow you to navigate to previous sections
const RestartButtons = (props) => {
  return (
    <div>
      <button type="button" onClick={props.restart1} className="restart-button">
        {" "}
        Try new departure city{" "}
      </button>
      <button type="button" onClick={props.restart2} className="restart-button">
        {" "}
        Try new destination{" "}
      </button>
      <button type="button" onClick={props.restart3} className="restart-button">
        {" "}
        Try new dates/currency{" "}
      </button>
    </div>
  );
};

const combineData = (data) => {
  let newData = data.Quotes.map((flight) => {
    return {
      quoteId: flight.QuoteId,
      minPrice: flight.MinPrice,
      direct: flight.Direct,
      outboundDate: flight.OutboundLeg.DepartureDate.substring(0, 10),
      inboundDate: flight.InboundLeg.DepartureDate.substring(0, 10),
      departureCode: data.Places[1].IataCode,
      departureCity: data.Places[1].CityName,
      arrivalCode: data.Places[0].IataCode,
      arrivalCity: data.Places[0].CityName,
      outboundAirline: findAirline(data, flight.OutboundLeg.CarrierIds[0]),
      inboundAirline: findAirline(data, flight.InboundLeg.CarrierIds[0])
    };
  });
  return newData;
};

const findAirline = (data, code) => {
  const airline = data.Carriers.find((element) => {
    return element.CarrierId === code;
  });
  return airline.Name;
};

const findSymbol = (data, code) => {
  const currency = data.find((element) => {
    return element.Code === code;
  });
  return currency.Symbol;
};

export default class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      step: 1,
      errorOccurred: false,
      isLoading: false,
      cityInputValue: "",
      cityData: [],
      cityPlaceId: "",
      destinationInputValue: "",
      destinationPlaceId: "",
      outboundDate: "",
      inboundDate: "",
      currencyData: [],
      currencyChoice: "USD",
      currencySymbol: "$",
      detailedQuoteData: []
    };
  }

  handleCityChange = (e) => {
    const step = this.state.step;
    if (step === 1) {
      this.setState({
        cityInputValue: e.target.value
      });
    } else if (step === 2) {
      this.setState({
        cityInputValue: e.target.value,
        step: 1
      });
    } else if (step === 3) {
      this.setState({
        destinationInputValue: e.target.value
      });
    } else {
      this.setState({
        destinationInputValue: e.target.value,
        step: 3
      });
    }
  };

  handleCitySubmit = (e) => {
    e.preventDefault();
    this.setState({ isLoading: true });
    if (this.state.step < 3) {
      this.setState({
        step: 2
      });
    } else {
      this.setState({
        step: 4
      });
    }
    this.searchCities();
  };

  handleTableChange = (e) => {
    if (this.state.step < 4) {
      this.setState({ cityPlaceId: e.target.value });
    } else if (this.state.step < 5) {
      this.setState({ destinationPlaceId: e.target.value });
    } else {
      this.setState({
        currencyChoice: e.value,
        currencySymbol: findSymbol(this.state.currencyData, e.value)
      });
    }
  };

  handleTableSubmit = () => {
    if (this.state.step < 3) {
      this.setState({ step: 3 });
    } else if (this.state.step < 5) {
      this.setState({ isLoading: true, step: 5 });
      this.searchCurrencies();
    } else {
      this.setState({ isLoading: true, step: 6 });
      this.searchQuotes();
    }
  };

  // date 1
  handleLastInputChange1 = (e) => {
    this.setState({
      outboundDate: e.target.value
    });
  };

  // date 2
  handleLastInputChange2 = (e) => {
    this.setState({
      inboundDate: e.target.value
    });
  };

  handleLastSubmit = () => {
    this.setState({ isLoading: true, step: 6 });
    this.searchQuotes();
  };

  handleRestart1 = () => {
    this.setState({ errorOccurred: false, step: 1 });
  };

  handleRestart2 = () => {
    this.setState({ errorOccurred: false, step: 3 });
  };

  handleRestart3 = () => {
    this.setState({ errorOccurred: false, step: 5 });
  };

  searchCities = () => {
    const queryVal =
      this.state.step >= 3
        ? this.state.destinationInputValue
        : this.state.cityInputValue;
    const options = {
      method: "GET",
      url:
        "https://skyscanner-skyscanner-flight-search-v1.p.rapidapi.com/apiservices/autosuggest/v1.0/US/USD/en-US/",
      params: { query: queryVal },
      headers: {
        "x-rapidapi-key": "3e51823148mshdd4da72cff66c94p1dc5e2jsn104efd1d46f2",
        "x-rapidapi-host":
          "skyscanner-skyscanner-flight-search-v1.p.rapidapi.com"
      }
    };
    axios
      .request(options)
      .then(function (response) {
        return response.data;
      })
      .then((data) => {
        this.setState({ isLoading: false, cityData: data.Places });
      })
      .catch((error) => {
        console.error(error);
        this.setState({ isLoading: false, errorOccurred: true });
      });
  };

  searchCurrencies = () => {
    const options = {
      method: "GET",
      url:
        "https://skyscanner-skyscanner-flight-search-v1.p.rapidapi.com/apiservices/reference/v1.0/currencies",
      headers: {
        "x-rapidapi-key": "3e51823148mshdd4da72cff66c94p1dc5e2jsn104efd1d46f2",
        "x-rapidapi-host":
          "skyscanner-skyscanner-flight-search-v1.p.rapidapi.com"
      }
    };
    axios
      .request(options)
      .then(function (response) {
        return response.data;
      })
      .then((data) => {
        this.setState({ isLoading: false, currencyData: data.Currencies });
      })
      .catch((error) => {
        console.error(error);
        this.setState({ isLoading: false, errorOccurred: true });
      });
  };

  searchQuotes = () => {
    let outbound = this.state.outboundDate;
    if (outbound === "") outbound = "anytime";

    let inbound = this.state.inboundDate;
    if (inbound === "") inbound = "anytime";

    const options = {
      method: "GET",
      url: `https://skyscanner-skyscanner-flight-search-v1.p.rapidapi.com/apiservices/browsequotes/v1.0/US/${this.state.currencyChoice}/en-US/${this.state.cityPlaceId}/${this.state.destinationPlaceId}/${outbound}/${inbound}`,
      params: { inboundpartialdate: "2021-04" },
      headers: {
        "x-rapidapi-key": "3e51823148mshdd4da72cff66c94p1dc5e2jsn104efd1d46f2",
        "x-rapidapi-host":
          "skyscanner-skyscanner-flight-search-v1.p.rapidapi.com"
      }
    };
    axios
      .request(options)
      .then(function (response) {
        return response.data;
      })
      .then((data) => {
        const detailedQuoteData = combineData(data);
        this.setState({
          isLoading: false,
          detailedQuoteData: detailedQuoteData
        });
      })
      .catch((error) => {
        console.error(error);
        this.setState({ isLoading: false, errorOccurred: true });
      });
  };

  render() {
    const step = this.state.step;
    const topHeader = (
      <div className="header">
        <h1>Find the cheapest round trips to anywhere in the world!</h1>
        <img
          alt="plane icon"
          src="https://drive.google.com/uc?export=view&id=17XCrch7kf8kHg29xLL3RHGN89EB6OCV6"
        />
      </div>
    );

    const citySearchBar = (
      <CitySearchBar
        step={step}
        value={this.state.cityInputValue}
        handleCityChange={this.handleCityChange}
        handleCitySubmit={this.handleCitySubmit}
      />
    );

    const destinationSearchBar = (
      <CitySearchBar
        step={step}
        value={this.state.destinationInputValue}
        handleCityChange={this.handleCityChange}
        handleCitySubmit={this.handleCitySubmit}
      />
    );

    const cityResults = (
      <ResultsTable
        step={step}
        cityData={this.state.cityData}
        value={this.state.cityInputValue}
        handleTableSubmit={this.handleTableSubmit}
        handleTableChange={this.handleTableChange}
        placeId={this.state.cityPlaceId}
      />
    );

    const destinationResults = (
      <ResultsTable
        step={step}
        cityData={this.state.cityData}
        value={this.state.destinationInputValue}
        handleTableSubmit={this.handleTableSubmit}
        handleTableChange={this.handleTableChange}
        placeId={this.state.destinationPlaceId}
      />
    );

    const datesAndCurrency = (
      <DatesAndCurrency
        currencyData={this.state.currencyData}
        currencyChoice={this.state.currencyChoice}
        value1={this.state.outboundDate}
        value2={this.state.inboundDate}
        handleLastSubmit={this.handleLastSubmit}
        handleLastInputChange1={this.handleLastInputChange1}
        handleLastInputChange2={this.handleLastInputChange2}
        handleTableChange={this.handleTableChange}
      />
    );

    const quotes = (
      <QuotesTable
        quoteData={this.state.detailedQuoteData}
        currencyChoice={this.state.currencySymbol}
      />
    );

    const restartButtons = (
      <RestartButtons
        restart1={this.handleRestart1}
        restart2={this.handleRestart2}
        restart3={this.handleRestart3}
      />
    );

    if (this.state.errorOccurred) {
      return (
        <div className="App">
          {topHeader}
          <h2> An error occurred, try again. </h2>
          {restartButtons}
        </div>
      );
    }
    if (this.state.isLoading) {
      return (
        <div className="App">
          {topHeader}
          <h2> Loading... </h2>
        </div>
      );
    }
    if (step === 1) {
      return (
        <div className="App">
          {topHeader}
          {citySearchBar}
        </div>
      );
    } else if (step === 2) {
      return (
        <div className="App">
          {topHeader}
          {citySearchBar}
          {cityResults}
        </div>
      );
    } else if (step === 3) {
      return (
        <div className="App">
          {topHeader}
          {destinationSearchBar}
        </div>
      );
    } else if (step === 4) {
      return (
        <div className="App">
          {topHeader}
          {destinationSearchBar}
          {destinationResults}
        </div>
      );
    } else if (step === 5) {
      return (
        <div className="App">
          {topHeader}
          {datesAndCurrency}
        </div>
      );
    } else {
      return (
        <div className="App">
          {topHeader}
          {quotes}
          {restartButtons}
        </div>
      );
    }
  }
}
